# ZYON PRIVATE — Android

Projeto Android Studio com simulador independente. Não se conecta ao Free Fire, não lê memória do jogo e não injeta código no processo do jogo.

## Abrir e compilar
1. Extraia `ZYON_PRIVATE_Android.zip`.
2. Abra a pasta `ZYON_PRIVATE_Android` no Android Studio (Hedgehog ou mais recente).
3. Aguarde a sincronização do Gradle e instale o Android SDK Platform 35 se solicitado.
4. Selecione `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Recursos
- ESP demonstrativo: Box corner/full/3D, nome, distância, vida, tracer, skeleton, cor, opacidade, espessura e tamanho de texto.
- Aim Lab: intensidade, FOV, suavização, ponto e prioridade de alvo com visualização animada.
- Alvos fictícios selecionáveis/adicionáveis.
- Perfis locais, exportação JSON e restauração de padrão.
- Interface responsiva para Android.

Requisitos: Android Studio, JDK 17 e Android SDK Platform 35.

## Compilar sem PC (GitHub Actions)
1. Crie uma conta gratuita no GitHub pelo navegador do celular.
2. Crie um repositório novo e envie todos os arquivos desta pasta (incluindo a pasta oculta `.github/workflows`).
3. Abra a aba **Actions**, selecione **Build ZYON PRIVATE APK** e toque em **Run workflow** se a compilação não iniciar automaticamente.
4. Quando terminar com sucesso, abra a execução e baixe o artefato **ZYON-PRIVATE-APK**. Dentro dele estará `app-debug.apk`.
